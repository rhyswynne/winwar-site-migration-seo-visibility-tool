=== Check Search Engine Visibility on Migration ===
Tags: seo, migration, database, search engines, blog visibility, visibility, robots.txt
Requires at least: 3.0
Tested up to: 3.7.1
Version: 0.1
Stable tag: 0.1
Contributors: rhyswynne
Donate link: http://winwar.co.uk/plugins/check-search-engine-visibility-migration/#donate

Checks if a site has been migrated and if it's inivisible to search engines. If so, then the site warns you on this and notifies you to act.

== Description ==
This plugin is designed for people who has a developmental site that is different from the live site.

This plugin will warn you should you have blocked search engines in your blog. If you then move the database from your developmental site to your live installation, or change your blog's domain URL, then the warning will reappear, and not move until you have either unblocked search engines or made the plugin aware you have changed domains.

It's designed to help stop you accidentally blocking your live WordPress installation from search engines.

== Installation ==

1. Upload the plugin (unzipped) into `/wp-content/plugins/`.
2. Activate the plugin under the "Plugins" menu.
3. If your site is invisible to search engines, a big error box appears on the top of the screen. It will instruct you on what to do after that.

== Frequently Asked Questions ==
= I have had a look at the code and noticed a `base64_encode/decode` call. They can be used to hide code. Why have you got this? =
This simply converts the current URL to a hidden string, so if you're doing a database search/replace from developmental URL's to live URL's, then you won't search/replace our option.

== Change Log ==
= 0.1 (28/11/13) =
* Plugin Launched